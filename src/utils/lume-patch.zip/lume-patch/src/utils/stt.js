import { isLumeSpeaking } from './tts';

// Lazy init — never evaluated at import time, only when called after a user gesture
function getSpeechRecognition() {
  return window.SpeechRecognition || window.webkitSpeechRecognition || null;
}

export const startListening = (onModuleSwitch, onSpeech) => {
  const SpeechRecognition = getSpeechRecognition();

  if (!SpeechRecognition) {
    console.warn("Speech recognition not supported in this browser.");
    return null;
  }

  const recognition = new SpeechRecognition();
  recognition.continuous = true;
  recognition.lang = 'en-ZA'; // SA English for better accent matching
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  let isIntentionallyStopped = false;

  recognition.onresult = (event) => {
    // Guard: don't process our own TTS output
    if (isLumeSpeaking()) {
      console.log("Lume is speaking, ignoring mic input.");
      return;
    }

    const transcript = event.results[event.results.length - 1][0].transcript.toLowerCase().trim();
    console.log("STT transcript:", transcript);

    if (transcript.includes('vision mode') || transcript.includes('look around')) {
      onModuleSwitch('vision');
    } else if (
      transcript.includes('simplify mode') ||
      transcript.includes('read text') ||
      transcript === 'read' ||
      transcript.includes('read mode')
    ) {
      onModuleSwitch('simplify');
    } else if (onSpeech) {
      onSpeech(transcript);
    }
  };

  recognition.onerror = (event) => {
    if (event.error === 'not-allowed') {
      isIntentionallyStopped = true;
      console.error("Microphone permission denied.");
      return;
    }
    // no-speech and aborted are non-fatal, onend will restart
    console.warn("STT error (non-fatal):", event.error);
  };

  recognition.onend = () => {
    if (!isIntentionallyStopped) {
      // Small delay avoids instant-restart race on Android
      setTimeout(() => {
        try { recognition.start(); }
        catch (e) { console.warn("STT restart failed:", e.message); }
      }, 300);
    }
  };

  try {
    recognition.start();
    console.log("STT started.");
  } catch (e) {
    console.error("STT initial start failed:", e.message);
    return null;
  }

  return {
    stop: () => {
      isIntentionallyStopped = true;
      try { recognition.stop(); } catch (e) { /* already stopped */ }
    }
  };
};
